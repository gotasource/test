import { Model } from "./Model";
export class Category extends Model {
}
