import { Model } from "./Model";
export class SiteInfo extends Model {
}
