import { Model } from "./Model";
export class Product extends Model {
}
